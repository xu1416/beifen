# AutoJs-Docs

Auto.js文档。可在 https://hyb1996.github.io/AutoJs-Docs 浏览。

文档尚在完善中，可能有文档描述和代码实际行为有出入的情况。

模板、样式、generator来自[Node.js](https://github.com/nodejs/node/tree/master/doc)。